# KissFFT

Software FFT library used for devices that do not have hardware accelerated RFFT, or where we want to use mixed-radix FFT. Based off of https://github.com/mborgerding/kissfft.
